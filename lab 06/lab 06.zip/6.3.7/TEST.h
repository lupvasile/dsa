#ifndef TEST_H_INCLUDED
#define TEST_H_INCLUDED

#include <stdio.h>

#define nr_entry 1e4


void makeTest(FILE *fin);

#endif // TEST_H_INCLUDED
